
function add_contact_info(login,api_key,account)
{
var id= $($('input[name="ID"]')[0]).val();
$($('.linked-form')[0]).append("<div id='info_contact'><a id='href' href='#'>показать/скрыть сделки</a><div id='leads'>Получаем список</div></div>");
$($('.linked-form__fields')[0]).insertAfter("#info_contact"); 
$('#leads').css('display','none');
console.log ('id='+id+'&api_key='+api_key+'&login='+login+'&account='+account);


$('#href').on('click',function()
{
	$('#leads').load('https://zad1/','id='+id+'&api_key='+api_key+'&login='+login+'&account='+account);
	if($('#leads').css('display')=='none')
	
	{
		$('#leads').css('display','block')
	}
	else
	{
		$('#leads').css('display','none')
	}
});

}

define(['jquery'], function($){
    var CustomWidget = function () {
    	var self = this;
		this.callbacks = {
			render: function(){
				console.log('render');
				return true;
			},
			init: function(){
				console.log('init');
				return true;
			},
			bind_actions: function(){
				console.log('bind_');
				var settings=self.get_settings();
				add_contact_info(settings.login,settings.api_key,settings.account);
				return true;
			},
			settings: function(){
				return true;
			},
			onSave: function(){
				alert('click');
				return true;
			},
			destroy: function(){
				
			},
			contacts: {
					//select contacts in list and clicked on widget name
					selected: function(){
						console.log('contacts');
					}
				},
			leads: {
					//select leads in list and clicked on widget name
					selected: function(){
						console.log('leads');
					}
				},
			tasks: {
					//select taks in list and clicked on widget name
					selected: function(){
						console.log('tasks');
					}
				}
		};
		return this;
    };

return CustomWidget;
});